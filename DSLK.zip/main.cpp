#include <iostream>

using namespace std;

struct node
{
    int value;
    node *nextItem;
};

struct listNode
{
    node *head;
    node *tail;
};

void createEmptyList(listNode &list)
{
    list.head = NULL;
    list.tail = NULL;
}

node *initNode(int value)
{
    node *p;
    p = new node;
    p->value = value;
    p->nextItem = NULL;
    return p;
}

void insertToList(int value, listNode &list)
{
    node *p = initNode(value);
    if (list.head == NULL)
    {
        list.head = p;
        list.tail = list.head;
    }
    else
    {
        list.tail->nextItem = p;
        list.tail = p;
    }
}

void initList(listNode &list)
{
    createEmptyList(list);
    for (int i = 1; i <= 10; i++)
        insertToList(i, list);
}

void printList(listNode list)
{
    cout << "Danh sach lien ket:\t";
    if (list.head == NULL)
        return;
    else
    {
        node *p = list.head;
        while (p != NULL)
        {
            cout << p->value << '\t';
            p = p->nextItem;
        }
    }
}

void removeNodeWithValue(int value, listNode &list)
{
    cout << "\nXoa " << value << " ra khoi danh sach\n";
    if (list.head != NULL)
    {
        node *p = list.head;
        node *q;
        while (p != NULL)
        {
            if (p->value == value)
            {
                // Neu la node head
                if (list.head == p)
                {
                    list.head = list.head->nextItem;
                    if (list.head == NULL)
                        list.tail = NULL;
                }
                // Neu la node tail
                else if (list.tail == p)
                {
                    q->nextItem = NULL;
                    list.tail = q;
                    if (list.tail == NULL)
                        list.head = NULL;
                }
                // Nguoc lai
                else
                {
                    q->nextItem = p->nextItem;
                }
                delete p;
            }
            if (p != list.tail)
                q = p;
            p = p->nextItem;
        }
    }
}

int main()
{
    listNode list;
    initList(list);
    printList(list);
    removeNodeWithValue(5, list);
    printList(list);
    return 0;
}
