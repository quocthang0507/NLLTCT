#include <iostream>
#include <string.h>

using namespace std;

struct NV
{
  char Ten[20];
  double Luong;
};

void ChenNV(char Ten[20], double luong, NV ds[10], int &n)
{
  strcpy(ds[n].Ten,Ten);
  ds[n].Luong=luong;
  n++;
}

void InDS(NV ds[10], int n)
{
  for(int i=0;i<n;i++)
    cout<< "\n" << ds[i].Ten << '\t' <<ds[i].Luong;
}

void HoanVi(NV &a, NV &b)
{
  NV c = a;
  a=b;
  b=c;
}

void SapXep(NV ds[10], int n)
{
  for(int i=0;i<n;i++)
    for(int j=i+1;j<n;j++)
    {
      if(ds[i].Luong>ds[j].Luong || (ds[i].Luong==ds[j].Luong && strcmp(ds[i].Ten, ds[j].Ten)>0))
        HoanVi(ds[i], ds[j]);
    }
}

int main() {
  NV ds[10];
  int n=0;
  ChenNV("Binh", 150000, ds, n);
  ChenNV("Thang", 100000, ds, n);
  ChenNV("Nam", 100000, ds, n);
  ChenNV("An", 150000, ds, n);
  ChenNV("Cuong", 160000, ds, n);
  ChenNV("Chung", 130000, ds, n);
  ChenNV("Dung", 100000, ds, n);
  InDS(ds, n);
  SapXep(ds, n);
  cout<<"\n\nDanh sach moi: ";
  InDS(ds, n);
}